CAMPUSHUB - WEB DEVELOPMENT WEEK 2

Files:
1. index.html
2. style.css
3. script.js

TASK 1:
CSS styling, external CSS, element/class/ID selectors, colors, fonts,
backgrounds, borders and buttons.

TASK 2:
Box model, margin, padding, borders, border radius, Flexbox, CSS Grid
and media queries for tablet and mobile.

TASK 3:
JavaScript variables, let, const, data types, operators, user input,
conditions, loops and functions.

TASK 4:
DOM element selection, text changes, style changes, button events,
input validation and show/hide content.

TASK 5:
Theme toggle, digital clock, character counter, calculator and to-do list.

TASK 6:
Complete responsive mini website combining HTML, CSS and JavaScript.

HOW TO RUN:
1. Open this folder in VS Code.
2. Open index.html.
3. Right-click index.html.
4. Select "Open with Live Server".
   OR simply double-click index.html to open it in a browser.
5. Test the buttons, dark mode, clock, calculator, counter, to-do list
   and contact form.

For submission:
Keep all 3 files in the same folder and ZIP the folder.
Suggested ZIP name:
WD_Week2_YourName.zip
