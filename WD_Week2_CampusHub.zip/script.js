// =========================================
// CampusHub - Week 2 JavaScript
// TASK 3, TASK 4 and TASK 5
// =========================================

// ---------- Mobile Menu ----------
const menuBtn = document.getElementById("menuBtn");
const navLinks = document.getElementById("navLinks");

menuBtn.addEventListener("click", function () {
    navLinks.classList.toggle("show");
});

// ---------- TASK 5: Theme Toggle ----------
const themeBtn = document.getElementById("themeBtn");

themeBtn.addEventListener("click", function () {
    document.body.classList.toggle("dark");

    if (document.body.classList.contains("dark")) {
        themeBtn.textContent = "☀️ Light";
    } else {
        themeBtn.textContent = "🌙 Dark";
    }
});

// ---------- TASK 5: Digital Clock ----------
const clock = document.getElementById("clock");

function updateClock() {
    const now = new Date();

    let hours = String(now.getHours()).padStart(2, "0");
    let minutes = String(now.getMinutes()).padStart(2, "0");
    let seconds = String(now.getSeconds()).padStart(2, "0");

    clock.textContent = hours + ":" + minutes + ":" + seconds;
}

updateClock();
setInterval(updateClock, 1000);

// ---------- TASK 4: Button Click + DOM ----------
const helloBtn = document.getElementById("helloBtn");
const helloMessage = document.getElementById("helloMessage");

helloBtn.addEventListener("click", function () {
    helloMessage.textContent = "Hello! Welcome to CampusHub 👋";
});

// ---------- TASK 3: Variables and Operators ----------
const variableBtn = document.getElementById("variableBtn");
const variableOutput = document.getElementById("variableOutput");

variableBtn.addEventListener("click", function () {
    let marks = 75;
    const bonus = 5;
    let total = marks + bonus;
    let passed = total >= 40;

    variableOutput.textContent =
        "Marks: " + marks +
        " + Bonus: " + bonus +
        " = Total: " + total +
        ". Passed: " + passed;
});

// ---------- TASK 3: User Input + Condition ----------
const ageBtn = document.getElementById("ageBtn");
const ageInput = document.getElementById("ageInput");
const ageOutput = document.getElementById("ageOutput");

ageBtn.addEventListener("click", function () {
    let age = Number(ageInput.value);

    if (ageInput.value === "" || age <= 0) {
        ageOutput.textContent = "Please enter a valid age.";
        ageOutput.style.color = "#dc2626";
    } else if (age < 18) {
        ageOutput.textContent = "You are a minor.";
        ageOutput.style.color = "#d97706";
    } else {
        ageOutput.textContent = "You are an adult.";
        ageOutput.style.color = "#15803d";
    }
});

// ---------- TASK 3: Loop + Function ----------
const loopBtn = document.getElementById("loopBtn");
const loopOutput = document.getElementById("loopOutput");

function makeNumberList(limit) {
    let result = "";

    for (let i = 1; i <= limit; i++) {
        result += i;

        if (i < limit) {
            result += ", ";
        }
    }

    return result;
}

loopBtn.addEventListener("click", function () {
    loopOutput.textContent =
        "For loop result: " + makeNumberList(5);
});

// ---------- TASK 5: Character Counter ----------
const messageInput = document.getElementById("messageInput");
const charCount = document.getElementById("charCount");

messageInput.addEventListener("input", function () {
    charCount.textContent = messageInput.value.length;
});

// ---------- TASK 5: Calculator ----------
const calculateBtn = document.getElementById("calculateBtn");
const calcResult = document.getElementById("calcResult");

calculateBtn.addEventListener("click", function () {
    const firstText = document.getElementById("num1").value;
    const secondText = document.getElementById("num2").value;
    const first = Number(firstText);
    const second = Number(secondText);
    const operator = document.getElementById("operator").value;

    if (firstText === "" || secondText === "") {
        calcResult.textContent = "Result: Enter both numbers.";
        return;
    }

    let result;

    if (operator === "+") {
        result = first + second;
    } else if (operator === "-") {
        result = first - second;
    } else if (operator === "*") {
        result = first * second;
    } else {
        if (second === 0) {
            calcResult.textContent = "Result: Cannot divide by zero.";
            return;
        }

        result = first / second;
    }

    calcResult.textContent = "Result: " + result;
});

// ---------- TASK 5: To-Do List ----------
const todoInput = document.getElementById("todoInput");
const addTodoBtn = document.getElementById("addTodoBtn");
const todoList = document.getElementById("todoList");

function addTodo() {
    const task = todoInput.value.trim();

    if (task === "") {
        return;
    }

    const li = document.createElement("li");
    const text = document.createElement("span");
    const deleteBtn = document.createElement("button");

    text.textContent = task;
    deleteBtn.textContent = "Delete";
    deleteBtn.className = "delete-btn";

    deleteBtn.addEventListener("click", function () {
        li.remove();
    });

    li.appendChild(text);
    li.appendChild(deleteBtn);
    todoList.appendChild(li);

    todoInput.value = "";
}

addTodoBtn.addEventListener("click", addTodo);

todoInput.addEventListener("keydown", function (event) {
    if (event.key === "Enter") {
        addTodo();
    }
});

// ---------- TASK 4: Show / Hide ----------
const toggleBtn = document.getElementById("toggleBtn");
const tip = document.getElementById("tip");

toggleBtn.addEventListener("click", function () {
    if (tip.style.display === "block") {
        tip.style.display = "none";
        toggleBtn.textContent = "Show Tip";
    } else {
        tip.style.display = "block";
        toggleBtn.textContent = "Hide Tip";
    }
});

// ---------- TASK 4: Form Validation ----------
const contactForm = document.getElementById("contactForm");
const nameInput = document.getElementById("nameInput");
const emailInput = document.getElementById("emailInput");
const formMessage = document.getElementById("formMessage");

contactForm.addEventListener("submit", function (event) {
    event.preventDefault();

    const name = nameInput.value.trim();
    const email = emailInput.value.trim();

    if (name.length < 2) {
        formMessage.textContent = "Please enter your name.";
        formMessage.style.color = "#dc2626";
        return;
    }

    if (!email.includes("@") || !email.includes(".")) {
        formMessage.textContent = "Please enter a valid email.";
        formMessage.style.color = "#dc2626";
        return;
    }

    formMessage.textContent =
        "Thanks " + name + "! Form submitted successfully.";
    formMessage.style.color = "#15803d";

    contactForm.reset();
});
